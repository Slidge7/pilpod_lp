# S7 — s7.ma

The studio site, rebuilt as a single-page application. Same design, same copy.
Internal links no longer reload the page, and the backdrop no longer drops frames.

- **No framework, no runtime dependencies.** TypeScript + Vite, pure CSS.
  About 13 kB of JS and 8 kB of CSS once gzipped.
- **Every route is prerendered to real HTML**, so crawlers, link previews and
  visitors without JavaScript still get the full page, its metadata and JSON-LD.
- **After first paint, the router takes over.** Links swap `<main>` in place
  with a View Transition. The nav, the GMT clock, the footer and the backdrop
  are never re-rendered.

## Commands

```bash
npm install
npm run dev          # dev server; renders routes the same way the build does
npm run build        # client build → SSR build → prerender into dist/
npm run serve:dist   # serve dist/ the way Firebase does (clean URLs, real 404)
npm run typecheck
firebase deploy      # predeploy runs the build
```

## Layout

```
index.html              shell template (placeholders filled at build time)
src/
  main.ts               client entry: starts the chrome, hands over to the router
  ssr.ts                build-time entry: the same routes, rendered in Node
  router/router.ts      history routing, View Transitions, focus + announcements
  router/scroll.ts      per-entry scroll restoration, anchor offsets
  app/shell.ts          nav, time strip, backdrop, footer (rendered once)
  app/head.ts           per-route <head>: build time and runtime
  routes/               home, reqtone, notfound; each has render() and mount()
  ui/                   clock, nav, reveal, standard ledger, pointer lens
  styles/               tokens (two themes), base, ambient, nav, transitions, pages
scripts/prerender.mjs   writes dist/index.html, dist/reqtone/index.html, dist/404.html,
                        sitemap.xml, font preloads, CSP
scripts/serve.mjs       local Firebase-like static server
```

### Adding a page

1. Create `src/routes/<name>.ts` that exports a `Route` with an `id`, a `path`,
   a `theme`, `meta`, `render()` and optionally `mount()`.
2. Add it to `routes` and `prerenderable` in `src/routes/index.ts`.
3. Put its styles in `src/styles/<name>.css` and import that file in `main.ts`.

It will be prerendered and added to the sitemap automatically.

## Why it was slow, and what changed

Measured with Chrome tracing, using the same scripted session on the old and new
builds (sandbox with no GPU, so absolute numbers are pessimistic; compare the ratios):

| Scenario | Old | New |
|---|---|---|
| Home, idle | 5 fps, worst frame 400 ms | 60 fps, 0 frames over 50 ms |
| Home, scrolling | 5 fps, worst frame 450 ms | 47 fps, 0 frames over 50 ms |
| Home, pointer moving | 6 fps, 162 janky frames | 60 fps, 0 |
| ReqTone (all three) | 9–10 fps | 60 fps, 0 |
| Pipeline CPU while scrolling | 18.4 s | 3.2 s (−82%) |
| Pipeline CPU during pointer sweep | 37.4 s | 4.2 s (−89%) |

Causes, in order of cost:

1. **`filter: blur(120px)` on three viewport-sized glows** that were also
   animating scale. The glows now paint a radial gradient whose stops follow the
   curve that blur produced, fitted from a numerical model of the original. The
   backdrop differs from the old one by 0.5/255 on average.
2. **A four-viewport grain layer with `mix-blend-mode: overlay`** sitting over
   moving layers. It is now viewport-sized, has no blend mode, and is cached.
3. **The pointer light repainted the whole screen on every mouse frame.** It is
   now a fixed-size disc moved with a transform.
4. **Cursor position was broadcast as inherited CSS custom properties**, which
   made the browser repaint the tiled zellige on every pointer frame. JS now
   writes transforms only to the three layers that move.
5. **The hero's pulsing dot animated `box-shadow`**, which repaints the hero
   every frame. It now uses `transform` and `opacity` only.
6. **Scroll handlers forced layout.** The ledger called
   `getBoundingClientRect()` on seven rows every frame. That and the nav state
   are now handled by IntersectionObservers, and the page has no scroll
   listeners at all.
7. **Google Fonts sat on the critical path.** Geist and Geist Mono are now
   self-hosted, content-hashed and preloaded.

The zellige lattice is pixel-identical to the original (verified by diff).

## Deliberate differences from the old site

- The 404 page is a route inside the app, so it keeps the nav, the clock and the
  backdrop.
- There is one footer on every page, so the footer on ReqTone is now the studio
  footer (7 px taller).
- The ReqTone favicon moved from `/assets/reqtone.svg` to `/icons/reqtone.svg`.
  `/assets/` now holds only content-hashed files that are cached forever.
- A strict Content-Security-Policy is injected into every page. Only our own
  scripts can run, and the one inline script is pinned by hash.
- The grain overlay is plain noise at 5.5% opacity instead of an overlay blend.
  Raise `.grain { opacity }` in `ambient.css` if it should read stronger.
- The Standard ledger keeps its original 40 px indent. The old stylesheet never
  reset `<ol>`, so that indent came from the browser default. It is now set
  explicitly.

## Migrating the repo

1. Branch first: `git checkout -b webapp`.
2. Delete the old `public/` folder. Its pages now live in `src/routes/`, and
   the new `public/` holds only static files (icons, robots.txt).
3. Copy this project into the repo root, replacing `firebase.json` and
   `.gitignore`.
4. Run `npm install && npm run build && npm run serve:dist`, then click around
   at http://localhost:4173.
5. Run `firebase deploy`.
