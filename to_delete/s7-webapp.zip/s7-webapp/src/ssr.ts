/**
 * Build-time entry.
 *
 * Vite compiles this to a Node bundle; scripts/prerender.mjs imports it and
 * writes one static HTML file per route. The route modules it pulls in are the
 * exact modules the browser runs, so a prerendered page and a client-rendered
 * one can never disagree.
 */
import { prerenderable, routes, fallback } from './routes';
import { renderBody } from './app/shell';
import { headTags, ORIGIN } from './app/head';
import type { Route } from './app/types';

export interface Page {
  /** Path of the file to write, relative to dist/ — e.g. "reqtone/index.html". */
  readonly file: string;
  readonly path: string;
  readonly title: string;
  readonly head: string;
  readonly body: string;
  readonly theme: string;
  readonly id: string;
  readonly canonical: string;
  readonly indexable: boolean;
}

const YEAR = new Date().getFullYear();

function fileFor(route: Route): string {
  if (route.path === '/') return 'index.html';
  if (route.id === 'notfound') return '404.html';
  return `${route.path.replace(/^\//, '')}/index.html`;
}

export function pages(): Page[] {
  return prerenderable.map((route) => {
    const head = headTags(route.meta);
    return {
      file: fileFor(route),
      path: route.path,
      title: head.title,
      head: head.tags.join('\n'),
      body: renderBody(route.render(), YEAR),
      theme: route.theme,
      id: route.id,
      canonical: ORIGIN + (route.meta.canonicalPath === '/' ? '/' : route.meta.canonicalPath),
      indexable: (route.meta.robots ?? 'index, follow').includes('index,'),
    };
  });
}

/** Used by the dev-server plugin so `vite dev` renders what `vite build` would. */
export function pageForPath(path: string): Page {
  const clean = path.replace(/\/+$/, '') || '/';
  const route = routes.find((r) => r.path === clean) ?? fallback;
  const head = headTags(route.meta);
  return {
    file: fileFor(route),
    path: route.path,
    title: head.title,
    head: head.tags.join('\n'),
    body: renderBody(route.render(), YEAR),
    theme: route.theme,
    id: route.id,
    canonical: ORIGIN + (route.meta.canonicalPath === '/' ? '/' : route.meta.canonicalPath),
    indexable: (route.meta.robots ?? 'index, follow').includes('index,'),
  };
}

export { ORIGIN };
