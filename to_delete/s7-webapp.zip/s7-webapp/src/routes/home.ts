import type { Route } from '../app/types';
import { arrow, arrowThin, pilpodGlyph, reqtoneMark } from '../lib/icons';
import { initReveal } from '../ui/reveal';
import { initStandard } from '../ui/standard';

const PRINCIPLES: ReadonlyArray<readonly [string, string]> = [
  ['Local First', 'Your data lives on your machine. The network is an enhancement, never a requirement.'],
  ['Privacy First', 'No tracking, no profiling, no quiet collection. What happens on your device stays there.'],
  ['Fast by Design', 'Performance is a design decision made early, not an optimisation pass added late.'],
  ['Minimal Dependencies', 'Every dependency is a liability we inherit. We take on very few, and we choose them slowly.'],
  ['Long-Term Maintainability', 'Written to be understood years from now, by whoever opens the file next.'],
  ['User Ownership', 'Open formats, easy export, no lock-in. You should be able to leave at any moment.'],
  ['Simplicity over Complexity', 'The hard work is deciding what not to build. We do that work before writing code.'],
];

const FACTS: ReadonlyArray<readonly [string, string]> = [
  ['Studio', 'S7 — Service7'],
  ['Based in', 'Morocco'],
  ['Focus', 'Desktop &amp; developer tools'],
  ['Model', 'Independent'],
];

const pad = (n: number): string => (n < 10 ? '0' : '') + n;

function principles(): string {
  return PRINCIPLES.map(
    ([title, body], i) => /* html */ `
        <li class="pr rv">
          <span class="pr-n">${pad(i + 1)}</span>
          <h3 class="pr-t">${title}</h3>
          <p class="pr-d">${body}</p>
        </li>`,
  ).join('');
}

function facts(): string {
  return FACTS.map(([k, v]) => `<div><dt>${k}</dt><dd>${v}</dd></div>`).join('\n          ');
}

export const home: Route = {
  id: 'home',
  path: '/',
  theme: 's7',

  meta: {
    title: 'S7 — Premium Software, Designed & Engineered in Morocco',
    description:
      'S7 is an independent software studio building premium desktop applications, developer tools and productivity software. Local-first, privacy-conscious, fast by design.',
    canonicalPath: '/',
    ogTitle: 'S7 — Premium Software, Designed & Engineered in Morocco',
    ogDescription:
      'An independent software studio building premium desktop applications, developer tools and productivity software.',
    themeColor: '#0A0A0B',
    jsonLd: {
      '@context': 'https://schema.org',
      '@type': 'Organization',
      name: 'S7',
      alternateName: 'Service7',
      url: 'https://s7.ma/',
      description:
        'An independent software studio building premium desktop applications, developer tools and productivity software.',
      address: { '@type': 'PostalAddress', addressCountry: 'MA' },
    },
  },

  render(): string {
    return /* html */ `
  <!-- ============ HERO ============ -->
  <section class="hero wrap" id="top">
    <p class="eyebrow"><span class="pulse"></span> Independent Software Studio</p>

    <h1>Premium software.<br><span class="muted">Built to last.</span></h1>

    <p class="hero-sub">
      S7 designs and engineers desktop applications and developer tools that are
      fast, local-first and privately yours — from Morocco, for everyone.
    </p>

    <div class="hero-cta">
      <a class="btn btn-primary" href="/#products">
        Explore products
        ${arrow()}
      </a>
      <a class="btn btn-ghost" href="/#standard">The S7 Standard</a>
    </div>

    <p class="hero-meta">
      <span>Est. Morocco</span>
      <span>Local-first</span>
      <span>Privacy-conscious</span>
      <span>Two products in build</span>
    </p>
  </section>

  <!-- ============ PRODUCTS ============ -->
  <section id="products" class="wrap">
    <p class="label rv"><span class="dot"></span> 01 — Products</p>

    <div class="section-head">
      <h2 class="rv">One studio. One ecosystem.</h2>
      <p class="rv" style="--d:80ms">
        Every S7 product is built on the same foundations, so they behave the same
        way, respect the same boundaries, and feel like they were made by the same hand.
      </p>
    </div>

    <div class="products">
      <article class="product is-soon rv" style="--d:0ms">
        <div class="product-top">
          <span class="product-idx">01</span>
          <span class="badge soon">Coming soon</span>
        </div>
        ${pilpodGlyph('product-glyph')}
        <h3>PilPod</h3>
        <p class="kind">Desktop media control</p>
        <p>Complete control of playback across your machine — instant, keyboard-native and out of your way until you need it.</p>
      </article>

      <article class="product is-pre rv" style="--d:120ms">
        <div class="product-top">
          <span class="product-idx">02</span>
          <span class="badge pre">Pre-release</span>
        </div>
        ${reqtoneMark('rt-card', 'product-glyph brand')}
        <h3>ReqTone</h3>
        <p class="kind">Native API client</p>
        <p>REST, GraphQL and Server-Sent Events in a native desktop shell. Every collection, variable and credential in one local SQLite file you own.</p>
        <a class="product-link" href="/reqtone">
          Product overview
          ${arrowThin()}
        </a>
      </article>
    </div>
  </section>

  <!-- ============ THE S7 STANDARD ============ -->
  <section id="standard" class="standard wrap">
    <p class="label rv"><span class="dot"></span> 02 — The S7 Standard</p>

    <div class="std-grid">
      <div class="std-aside rv">
        <h2>Seven commitments behind every release.</h2>
        <p>
          Not a manifesto. A set of engineering constraints we hold ourselves
          to, because they are what make software still feel good ten years
          after it shipped.
        </p>
        <p class="std-cap"><b class="std-count">00</b> / 07 — seven, held to</p>
        <div class="std-rail" aria-hidden="true"><i></i><i></i><i></i><i></i><i></i><i></i><i></i></div>
      </div>

      <ol class="std-list">${principles()}
      </ol>
    </div>
  </section>

  <!-- ============ ABOUT ============ -->
  <section id="about" class="wrap">
    <p class="label rv"><span class="dot"></span> 03 — About</p>

    <div class="about-grid">
      <p class="about-lead rv">
        S7 is an independent software studio,
        <em>designed and engineered in Morocco.</em>
      </p>

      <div class="about-body rv" style="--d:100ms">
        <p>
          We build premium desktop applications, developer tools and productivity
          software — a small catalogue, made carefully, maintained for the long term.
        </p>
        <p>
          Independence is the point. No investors setting the roadmap, no growth
          curve dictating what ships. We build what we would want to use, and we
          keep building it.
        </p>

        <dl class="facts">
          ${facts()}
        </dl>
      </div>
    </div>
  </section>`;
  },

  mount(main: HTMLElement): () => void {
    const stopReveal = initReveal(main);
    const stopStandard = initStandard(main);
    return () => {
      stopReveal();
      stopStandard();
    };
  },
};
