import type { Route } from '../app/types';
import { arrow, reqtoneMark } from '../lib/icons';
import { initReveal } from '../ui/reveal';

/** The six engineering decisions, with their trade-offs attached. */
const DECISIONS: ReadonlyArray<readonly [string, string]> = [
  [
    'A native shell, not a bundled browser',
    `ReqTone renders in the webview the operating system already provides and
     does its networking in Rust with <code>reqwest</code>, on a real thread,
     instead of shipping a browser engine and a JavaScript runtime alongside
     the app. The cost: the UI inherits whatever webview the OS gives it —
     which is why both themes are tested on all three platforms rather than
     assumed.`,
  ],
  [
    'Your data is a file you own',
    `Collections, project trees, environments, auth profiles and history are
     rows in an ordinary SQLite database in your application directory. Copy
     it, diff it, back it up, keep it on an encrypted volume, point the app at
     a different one, or open it in any SQLite browser. Export to JSON or
     Postman format is there too, so leaving is a file operation rather than a
     support ticket.`,
  ],
  [
    'Nothing waits on the network to start',
    `No account, no licence check, no auto-updater — and a standing rule that
     nothing on the startup path may block on a network call. The app opens
     with the cable out. What it does contact is the endpoint in your request,
     an OAuth token URL you configured, and your own sync server if you turn
     one on.`,
  ],
  [
    'Streaming is the default path, not a mode',
    `Every request goes down the same streaming code, so a response renders as
     it is written and the window stays usable while the stream is open. There
     is no separate event-stream request type to switch into and no second
     implementation to diverge — which also means a <code>POST</code> with a
     JSON body streams, which is what most LLM endpoints need.`,
  ],
  [
    'Scopes resolve one way',
    `A variable resolves request first, then project, then global. A staging
     token and a sandbox token can both be called <code>{{token}}</code>
     without either surprising you, and the manager shows which values are
     unused and whether a value lands in params, body or headers.`,
  ],
  [
    'Getting work in and out is a file operation',
    `Postman Collection v2.1, OpenAPI and Swagger 3.0 in JSON or YAML, raw
     cURL commands and <code>.reqtone</code> archives all import — bringing
     folder trees, headers, query params, auth profiles and bodies with them.
     Export runs the same way. Scripts are the known gap: pre-request and test
     scripts written in JavaScript do not transfer.`,
  ],
];

/** Every subsystem, grouped as it appears in the window. */
const FEATURES: ReadonlyArray<readonly [string, readonly string[]]> = [
  [
    'Workspace',
    [
      '<b>Projects → folders → requests</b>, nested as deep as you like',
      "<b>Project colour accents</b> — the active tab carries its parent project's border colour",
      '<b>Dirty-state dots</b> — an edited URL, header or body raises a marker',
      '<b>Session restore</b> — every tab, sub-tab and draft body comes back',
    ],
  ],
  [
    'Streaming',
    [
      '<b>One send path</b> — no streaming mode to switch into',
      '<b>Live chunks and an elapsed timer</b> — usable while the stream is open',
      '<b>Inspectable frames</b> — events, data and errors categorised as they land',
      '<b>Copy any chunk</b> straight out of the frame list',
    ],
  ],
  [
    'Editors',
    [
      '<b>Dual-pane GraphQL</b> — query above, variables below, separate Monaco instances',
      '<b>Operation names resolved</b> so a variables typo never reads as a query error',
      '<b>Live JSON validation</b> — inline markers and a valid/invalid pill',
      '<b>Form and multipart</b> — key-value grids, file attachments, boundaries handled',
    ],
  ],
  [
    'Auth',
    [
      '<b>Bearer, API key, Basic and OAuth2</b> profiles',
      '<b>Set once at the project</b>, inherited by everything beneath it',
      '<b>Per-endpoint override</b> without disturbing its siblings',
      '<b>Variables interpolate in auth headers</b> too',
    ],
  ],
  [
    'Variables',
    [
      '<b>Three scopes</b> — request beats project, project beats global',
      '<b>Unused values flagged</b> in the manager',
      '<b>Usage shown per row</b> — params, body or headers',
      '<b>Space N</b> promotes a selection into a scoped variable, <b>Space V</b> inserts one',
    ],
  ],
  [
    'Storage',
    [
      '<b>One <code>db.sqlite</code></b> — collections, environments, auth, history',
      '<b>One-click workspace switching</b> — separate databases, separate blast radius',
      '<b>No startup network call</b> — no licence check, no update beacon',
      '<b>Portable</b> — copy the file, or export clean JSON / Postman format',
    ],
  ],
  [
    'Inspection',
    [
      '<b>Status, latency and size</b> in one pill row above the body',
      '<b>Fuzzy header filter</b> — find <code>set-cookie</code> in a 40-header response',
      '<b>Cookies with domain, path and flags</b> laid out',
      '<b>Binary rendering and PDF preview</b> in the response pane',
    ],
  ],
  [
    'History',
    [
      '<b>Every run written</b> to a searchable drawer in a background transaction',
      '<b>Replay</b> — restore a past payload and headers in one click',
      '<b>Filter by method or status</b> to narrow to the failures that matter',
      '<b>Grouped search</b> across the whole drawer',
    ],
  ],
  [
    'Set-up',
    [
      '<b>Imports</b> Postman v2.1, OpenAPI / Swagger 3.0, raw cURL, <code>.reqtone</code>',
      '<b>An agent can write the collection</b> — a ready-made prompt, no configuration',
      '<b>Your tree, not a flat dump</b> — controllers become folders',
      '<b>Example bodies from your own DTOs</b> rather than empty strings',
    ],
  ],
];

const SPECS: ReadonlyArray<readonly [string, string]> = [
  ['Shell', 'Tauri v2'],
  ['Core', 'Rust + reqwest'],
  ['Storage', 'SQLite'],
  ['Version', '0.1.0'],
];

const PLATFORMS: ReadonlyArray<readonly [string, string, boolean]> = [
  ['Windows', 'Builds, not published', true],
  ['macOS', 'Build job unverified', true],
  ['Linux', 'No pipeline yet', true],
  ['Version', 'v0.1.0 — pre-release', false],
  ['Built with', 'Rust · Tauri v2 · SQLite', false],
];

const pad = (n: number): string => (n < 10 ? '0' : '') + n;

function decisions(): string {
  return DECISIONS.map(
    ([title, body], i) => /* html */ `
      <li class="rv">
        <span class="n">${pad(i + 1)}</span>
        <h3>${title}</h3>
        <p>${body}</p>
      </li>`,
  ).join('');
}

function features(): string {
  return FEATURES.map(
    ([title, items], i) => /* html */ `
      <section class="fg rv"${i ? ` style="--d:${i * 60}ms"` : ''}>
        <h3>${title}</h3>
        <ul>
          ${items.map((li) => `<li>${li}</li>`).join('\n          ')}
        </ul>
      </section>`,
  ).join('');
}

export const reqtone: Route = {
  id: 'reqtone',
  path: '/reqtone',
  theme: 'reqtone',

  meta: {
    title: 'ReqTone — Native, local-first API client | S7',
    description:
      'ReqTone is a native desktop API client for REST, GraphQL and Server-Sent Events. Tauri v2, Rust and reqwest, and every collection, variable and credential in one local SQLite file you own. An S7 product.',
    canonicalPath: '/reqtone',
    ogTitle: 'ReqTone — Native, local-first API client',
    ogDescription:
      "REST, GraphQL and Server-Sent Events in a native desktop shell. One local SQLite file, no account, nothing in anyone else's cloud.",
    themeColor: '#101116',
    icon: '/icons/reqtone.svg',
    jsonLd: {
      '@context': 'https://schema.org',
      '@type': 'SoftwareApplication',
      name: 'ReqTone',
      applicationCategory: 'DeveloperApplication',
      operatingSystem: 'Windows, macOS, Linux',
      softwareVersion: '0.1.0',
      url: 'https://reqtone.com/',
      description:
        'A native, local-first desktop API client for REST, GraphQL and Server-Sent Events, built with Rust and Tauri v2.',
      publisher: { '@type': 'Organization', name: 'S7', url: 'https://s7.ma/' },
    },
  },

  render(): string {
    return /* html */ `
  <!-- ============ HERO ============ -->
  <section class="rt-hero wrap" id="top">
    <p class="crumb"><a href="/#products">S7 Products</a> <span>/</span> <span>02 — ReqTone</span></p>

    <div class="rt-head rv">
      ${reqtoneMark('rt-hero-grad', 'rt-mark')}
      <div class="rt-titles">
        <h1>ReqTone</h1>
        <p class="rt-kind">Native API client — REST · GraphQL · SSE</p>
      </div>
    </div>

    <p class="rt-lead rv" style="--d:80ms">
      A desktop API client for people who would rather not run
      <b>a browser inside a browser</b>. The shell is native, the networking is
      Rust on a real thread, and everything you build lives in one local SQLite
      file that belongs to you.
    </p>

    <dl class="spec rv" style="--d:140ms">
      ${SPECS.map(([k, v]) => `<div><dt>${k}</dt><dd>${v}</dd></div>`).join('\n      ')}
    </dl>

    <p class="methods rv" style="--d:180ms" aria-hidden="true">
      <span class="m-get">GET</span>
      <span class="m-post">POST</span>
      <span class="m-put">PUT</span>
      <span class="m-patch">PATCH</span>
      <span class="m-del">DELETE</span>
    </p>

    <div class="rt-cta rv" style="--d:220ms">
      <a class="btn btn-primary" href="https://reqtone.com/" target="_blank" rel="noopener">
        Visit reqtone.com
        ${arrow()}
      </a>
      <a class="btn btn-ghost" href="/#products">All S7 products</a>
      <span class="status-pill"><i></i> Pre-release · v0.1.0 not published</span>
    </div>
  </section>

  <!-- ============ THE PRODUCT ============ -->
  <section class="wrap">
    <p class="label rv"><span class="dot"></span> The product</p>

    <div class="prod">
      <div class="rv">
        <h2>Built for the loop you actually run.</h2>
        <p style="margin-top:1.5rem">
          Send, read, tweak, send again — a few hundred times a day. That loop is
          the whole job, and most API clients treat it as an afterthought behind a
          sync service, a login screen and a workspace invitation.
        </p>
        <p>
          <b>ReqTone is built around the loop and nothing else.</b> Projects,
          folders and requests nest as deep as the service does. Tabs carry their
          project's colour so a wall of open endpoints still reads at a glance.
          An edited URL, header or body raises a dirty marker before you can lose
          it, and reopening the app brings back every tab, sub-tab and draft body
          exactly as you left it.
        </p>
        <p>
          It is for developers and teams who work against APIs all day and want
          the tool to be fast, quiet, and entirely theirs.
        </p>
      </div>

      <div class="loop rv" style="--d:120ms">
        <p class="loop-bar"><i></i> the loop</p>
        <ol>
          <li><b>01</b> <span>Send</span> — one path, streaming by default</li>
          <li><b>02</b> <span>Read</span> — status, latency, size, frames as they land</li>
          <li><b>03</b> <span>Tweak</span> — Monaco, live validation, scoped variables</li>
          <li><b>04</b> <span>Again</span> — replay from a searchable history</li>
        </ol>
      </div>
    </div>
  </section>

  <!-- ============ ENGINEERING ============ -->
  <section class="wrap">
    <p class="label rv"><span class="dot"></span> Engineering</p>

    <div class="sec-head rv">
      <h2>Six decisions, with the trade-offs attached.</h2>
      <p>
        Each one of these cost something, which is the only kind of decision worth
        writing down.
      </p>
    </div>

    <ol class="eng">${decisions()}
    </ol>
  </section>

  <!-- ============ FEATURES ============ -->
  <section class="wrap">
    <p class="label rv"><span class="dot"></span> Features</p>

    <div class="sec-head rv">
      <h2>Everything in the window.</h2>
      <p>
        Every subsystem below exists to take a step out of that loop, not to fill a
        comparison chart.
      </p>
    </div>

    <div class="feat">${features()}
    </div>
  </section>

  <!-- ============ STATUS ============ -->
  <section class="wrap">
    <p class="label rv"><span class="dot"></span> Where it stands</p>

    <div class="rt-status">
      <div class="rv">
        <h2>Honest about the stage it is at.</h2>
        <p>
          ReqTone is pre-release at v0.1.0 and has not been published. The
          application builds, but code signing is the blocker standing between it
          and a download link — and S7 does not ship unsigned binaries to people
          who trust it.
        </p>
        <p class="note">Status as published on reqtone.com</p>
      </div>

      <dl class="plat rv" style="--d:100ms">
        ${PLATFORMS.map(
          ([k, v, warn]) => `<div><dt>${k}</dt><dd${warn ? ' class="v"' : ''}>${v}</dd></div>`,
        ).join('\n        ')}
      </dl>
    </div>
  </section>`;
  },

  mount(main: HTMLElement): () => void {
    return initReveal(main);
  },
};
