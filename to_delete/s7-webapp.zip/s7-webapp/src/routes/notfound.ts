import type { Route } from '../app/types';
import { arrow, s7Mark } from '../lib/icons';
import { initReveal } from '../ui/reveal';

export const notFound: Route = {
  id: 'notfound',
  path: '/404',
  theme: 's7',

  meta: {
    title: 'Page not found — S7',
    description: 'The address you followed does not lead anywhere on this site.',
    canonicalPath: '/404',
    ogTitle: 'Page not found — S7',
    ogDescription: 'The address you followed does not lead anywhere on this site.',
    themeColor: '#0A0A0B',
    robots: 'noindex',
  },

  render(): string {
    return /* html */ `
  <section class="nf wrap" id="top">
    <p class="code rv"><i></i> Error 404</p>

    <h1 class="rv" style="--d:60ms">This page<br><span class="muted">does not exist.</span></h1>

    <p class="nf-body rv" style="--d:120ms">
      The address you followed does not lead anywhere on this site — it may have
      moved, or it may never have been here at all.
    </p>

    <div class="cta rv" style="--d:180ms">
      <a class="btn btn-primary" href="/">
        Back to S7
        ${arrow()}
      </a>
      <a class="btn btn-ghost" href="/#products">Products</a>
    </div>

    <p class="nf-mark rv" style="--d:240ms">
      ${s7Mark()}
      S7 — Service7 · Made in Morocco
    </p>
  </section>`;
  },

  mount(main: HTMLElement): () => void {
    return initReveal(main);
  },
};
