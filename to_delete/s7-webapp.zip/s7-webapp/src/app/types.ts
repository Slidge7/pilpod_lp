/**
 * The contract every route implements.
 *
 * `render()` returns a string rather than DOM nodes on purpose: the exact same
 * function runs in Node at build time (to write static HTML for crawlers and
 * no-JS visitors) and in the browser during a client-side navigation. One
 * implementation, no drift between the two.
 */

export type Theme = 's7' | 'reqtone';

export interface RouteMeta {
  /** <title> */
  readonly title: string;
  /** <meta name="description"> */
  readonly description: string;
  /** Canonical path on the production origin, e.g. "/reqtone" */
  readonly canonicalPath: string;
  readonly ogTitle: string;
  readonly ogDescription: string;
  readonly themeColor: string;
  /** Overrides the default "index, follow". */
  readonly robots?: string;
  /** Serialised into a <script type="application/ld+json"> block. */
  readonly jsonLd?: Record<string, unknown>;
  /** Route-specific favicon href; falls back to the S7 mark. */
  readonly icon?: string;
}

export interface Route {
  /** Stable id, also used as the body data-route attribute. */
  readonly id: string;
  /** Path this route answers to, without a trailing slash (except "/"). */
  readonly path: string;
  /** Which token set the shell wears while this route is mounted. */
  readonly theme: Theme;
  readonly meta: RouteMeta;
  /** Inner HTML of <main>. Must be deterministic — it runs at build time too. */
  render(): string;
  /**
   * Client-only enhancement. Receives the freshly mounted <main>.
   * Returns a teardown that must release every listener and observer it took.
   */
  mount?(main: HTMLElement): () => void;
}

/** Everything a page needs in <head>, in the order it should be written. */
export interface HeadTags {
  readonly title: string;
  readonly tags: readonly string[];
}
