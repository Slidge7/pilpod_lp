import type { HeadTags, RouteMeta } from './types';
import { S7_FAVICON } from '../lib/icons';

/** Production origin. Canonical URLs are absolute against this, always. */
export const ORIGIN = 'https://s7.ma';

const esc = (s: string): string =>
  s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

const absolute = (path: string): string => ORIGIN + (path === '/' ? '/' : path);

/* ------------------------------------------------------- build-time <head> */

/**
 * The full set of head tags for a route, written into the static HTML at build
 * time. Crawlers and link unfurlers never run our JavaScript, so this is the
 * only version of the metadata they will ever see — it has to be complete.
 */
export function headTags(meta: RouteMeta): HeadTags {
  const url = absolute(meta.canonicalPath);
  const tags: string[] = [
    `<meta name="description" content="${esc(meta.description)}">`,
    `<meta name="theme-color" content="${meta.themeColor}">`,
    `<meta name="color-scheme" content="dark">`,
    `<link rel="canonical" href="${url}">`,
    `<meta name="robots" content="${meta.robots ?? 'index, follow'}">`,
    ``,
    `<meta property="og:type" content="website">`,
    `<meta property="og:site_name" content="S7">`,
    `<meta property="og:title" content="${esc(meta.ogTitle)}">`,
    `<meta property="og:description" content="${esc(meta.ogDescription)}">`,
    `<meta property="og:url" content="${url}">`,
    `<meta name="twitter:card" content="summary_large_image">`,
    `<meta name="twitter:title" content="${esc(meta.ogTitle)}">`,
    `<meta name="twitter:description" content="${esc(meta.ogDescription)}">`,
    ``,
    `<link rel="icon" id="favicon" href="${meta.icon ?? S7_FAVICON}"${meta.icon ? ' type="image/svg+xml"' : ''}>`,
  ];

  if (meta.jsonLd) {
    tags.push(
      ``,
      `<script type="application/ld+json" id="ld">\n${JSON.stringify(meta.jsonLd, null, 2)}\n</script>`,
    );
  }

  return { title: meta.title, tags };
}

/* ----------------------------------------------------------- runtime <head> */

function setMeta(selector: string, attr: 'content' | 'href', value: string): void {
  const el = document.head.querySelector(selector);
  if (el) el.setAttribute(attr, value);
}

/**
 * Bring the live document's head in line with the route that just mounted.
 * Every tag except JSON-LD exists in every prerendered page, so this is almost
 * entirely attribute rewrites.
 */
export function applyMeta(meta: RouteMeta): void {
  const url = absolute(meta.canonicalPath);

  document.title = meta.title;
  setMeta('meta[name="description"]', 'content', meta.description);
  setMeta('meta[name="theme-color"]', 'content', meta.themeColor);
  setMeta('meta[name="robots"]', 'content', meta.robots ?? 'index, follow');
  setMeta('link[rel="canonical"]', 'href', url);
  setMeta('meta[property="og:title"]', 'content', meta.ogTitle);
  setMeta('meta[property="og:description"]', 'content', meta.ogDescription);
  setMeta('meta[property="og:url"]', 'content', url);
  setMeta('meta[name="twitter:title"]', 'content', meta.ogTitle);
  setMeta('meta[name="twitter:description"]', 'content', meta.ogDescription);

  const icon = document.getElementById('favicon');
  if (icon) icon.setAttribute('href', meta.icon ?? S7_FAVICON);

  // Structured data: the only head tag that can legitimately appear or vanish
  // between routes (the 404 has none).
  let ld = document.getElementById('ld');
  if (meta.jsonLd) {
    if (!ld) {
      ld = document.createElement('script');
      ld.id = 'ld';
      ld.setAttribute('type', 'application/ld+json');
      document.head.append(ld);
    }
    ld.textContent = JSON.stringify(meta.jsonLd, null, 2);
  } else {
    ld?.remove();
  }
}
