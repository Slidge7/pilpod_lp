import { s7Mark, flagMA } from '../lib/icons';

/**
 * The persistent chrome: ambient backdrop, nav (with the Morocco time strip)
 * and footer. Rendered once — the router only ever replaces <main>, so none of
 * this remounts, the clock never restarts and the nav never repaints on a
 * route change.
 */

/* ------------------------------------------------------------------ ambient */

/**
 * Two backdrops live in the DOM at once and cross-fade on a theme change.
 * Both are pure CSS (tiled background-images and gradients); there is no SVG
 * element scaled to the viewport and no filter anywhere, which is what makes
 * them free to animate.
 */
export function renderAmbient(): string {
  return /* html */ `
<div class="ambient" aria-hidden="true">
  <div class="amb amb-s7">
    <span class="glow glow-a"></span>
    <span class="glow glow-b"></span>
    <span class="glow glow-c"></span>
    <span class="zellige"></span>
    <span class="zellige-lens"><span class="lens-inner"></span></span>
  </div>
  <div class="amb amb-reqtone">
    <span class="glow rt-glow-a"></span>
    <span class="glow rt-glow-b"></span>
    <span class="dev-grid"></span>
  </div>
  <span class="grain"></span>
  <span class="pointer-light"></span>
</div>`;
}

/* ---------------------------------------------------------------------- nav */

const NAV_LINKS = [
  { href: '/#products', label: 'Products', cls: '' },
  { href: '/#standard', label: 'The Standard', cls: 'hide-s' },
  { href: '/#about', label: 'About', cls: '' },
] as const;

export function renderNav(): string {
  const links = NAV_LINKS.map(
    (l) => `<a href="${l.href}"${l.cls ? ` class="${l.cls}"` : ''}>${l.label}</a>`,
  ).join('\n        ');

  return /* html */ `
<header class="nav" id="nav">
  <div class="tz" id="tz">
    <div class="tz-scroll" id="tzScroll" role="group" aria-label="Morocco time (GMT) and world clocks">
      <div class="tz-track">
        <div class="tz-side" id="tzWest"></div>
        <div class="tz-ma" id="tzMa" role="group" aria-label="Morocco time, GMT"
             title="Morocco · official time is GMT (GMT+0)">
          ${flagMA('tz-flag')}
          <span class="tz-gmt">GMT</span>
          <span class="tz-clock"><span id="tzMaHM">--:--</span><span class="tz-sec" id="tzMaS">:--</span></span>
        </div>
        <div class="tz-side" id="tzEast"></div>
      </div>
    </div>
  </div>
  <div class="wrap nav-inner">
    <a class="mark" href="/" aria-label="S7 — home">
      ${s7Mark()}
      <span class="name">S7</span>
      <span class="sub">Service7</span>
    </a>
    <nav class="nav-links" aria-label="Primary">
        ${links}
    </nav>
  </div>
  <span class="nav-progress" aria-hidden="true"></span>
</header>`;
}

/* ------------------------------------------------------------------- footer */

export function renderFooter(year: number): string {
  return /* html */ `
<footer>
  <div class="wrap">
    <div class="foot-top">
      <div>
        <div class="foot-mark">
          ${s7Mark()}
          <strong>S7</strong>
        </div>
        <p class="foot-tag">Premium software, designed and engineered for permanence.</p>
      </div>

      <div class="foot-nav">
        <div>
          <h4>Products</h4>
          <ul>
            <li><a href="/#products">PilPod</a></li>
            <li><a href="/reqtone">ReqTone</a></li>
          </ul>
        </div>
        <div>
          <h4>Studio</h4>
          <ul>
            <li><a href="/#standard">The S7 Standard</a></li>
            <li><a href="/#about">About</a></li>
          </ul>
        </div>
      </div>
    </div>

    <div class="foot-bottom">
      <span class="made"><i></i> Made in Morocco</span>
      <span>Designed &amp; engineered by S7</span>
      <span>&copy; <span id="yr">${year}</span> S7</span>
    </div>
  </div>
</footer>`;
}

/* -------------------------------------------------------------- whole shell */

/**
 * Body markup for a given route. `mainHtml` is the route's own render()
 * output; everything around it is identical on every page, which is precisely
 * why the router can leave it alone.
 */
export function renderBody(mainHtml: string, year: number): string {
  return /* html */ `<a class="skip" href="#main">Skip to content</a>
${renderAmbient()}
${renderNav()}
<main id="main" tabindex="-1">
${mainHtml}
</main>
${renderFooter(year)}
<p class="sr-live" id="routeLive" role="status" aria-live="polite"></p>`;
}
