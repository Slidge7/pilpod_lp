import type { Route } from '../app/types';
import { applyMeta } from '../app/head';
import {
  initScroll,
  currentKey,
  mintKey,
  remember,
  recall,
  scrollToHash,
  scrollToTop,
} from './scroll';

/**
 * A ~3 KB client router.
 *
 * Responsibilities, in the order they matter:
 *   1. never reload the document for an internal link;
 *   2. leave the nav, footer and backdrop untouched across a navigation;
 *   3. animate the swap with the View Transitions API, degrade to a CSS fade;
 *   4. put the reader where they expect to be (top, anchor, or where they
 *      were when they pressed Back);
 *   5. tell assistive technology that the page changed, because nothing in a
 *      client-side navigation does that on its own.
 */

export type RouterMode = 'history' | 'hash';

export interface RouterOptions {
  readonly routes: readonly Route[];
  readonly fallback: Route;
  readonly main: HTMLElement;
  /** Deployment base, e.g. "/" or "/preview/". Always leading + trailing slash. */
  readonly base?: string;
  readonly mode?: RouterMode;
}

interface Target {
  readonly path: string;
  readonly hash: string;
}

const canViewTransition =
  typeof document !== 'undefined' &&
  typeof (document as Document & { startViewTransition?: unknown }).startViewTransition ===
    'function';

const prefersReduced = (): boolean =>
  window.matchMedia('(prefers-reduced-motion: reduce)').matches;

export class Router {
  private readonly routes: readonly Route[];
  private readonly fallback: Route;
  private readonly main: HTMLElement;
  private readonly base: string;
  private readonly mode: RouterMode;

  private current: Route | null = null;
  private teardown: (() => void) | null = null;
  private key = 0;
  private navigating = false;

  constructor(opts: RouterOptions) {
    this.routes = opts.routes;
    this.fallback = opts.fallback;
    this.main = opts.main;
    this.base = opts.base ?? '/';
    this.mode = opts.mode ?? 'history';
  }

  /* ------------------------------------------------------------- lifecycle */

  start(): void {
    initScroll();
    this.key = currentKey();

    document.addEventListener('click', this.onClick, false);
    window.addEventListener('popstate', this.onPop);
    if (this.mode === 'hash') window.addEventListener('hashchange', this.onPop);

    const target = this.readLocation();
    const route = this.resolve(target.path);

    // The server already delivered this route's markup. Adopt it rather than
    // re-rendering: no flash, no wasted parse, and the reveal animations get
    // to play from their real starting state.
    this.current = route;
    this.applyRoute(route);
    this.rewriteLinks(document);
    this.teardown = route.mount?.(this.main) ?? null;

    // Honour a fragment the browser could not resolve before our markup was
    // interactive (and, in hash mode, could never resolve at all).
    if (target.hash) {
      requestAnimationFrame(() => scrollToHash(target.hash, 'instant'));
    }
  }

  stop(): void {
    document.removeEventListener('click', this.onClick, false);
    window.removeEventListener('popstate', this.onPop);
    window.removeEventListener('hashchange', this.onPop);
    this.teardown?.();
  }

  /* ------------------------------------------------------------- resolving */

  private resolve(path: string): Route {
    const clean = path.replace(/\/+$/, '') || '/';
    return this.routes.find((r) => r.path === clean) ?? this.fallback;
  }

  /** Current app path + fragment, independent of mode and base. */
  private readLocation(): Target {
    return (
      this.targetFromURL(new URL(location.href)) ?? { path: '/', hash: this.mode === 'hash' ? '' : location.hash }
    );
  }

  /** An app path turned into a URL this deployment can actually serve. */
  private href(path: string, hash: string): string {
    if (this.mode === 'hash') {
      return `${this.base}#${path}${hash}`;
    }
    const joined = path === '/' ? this.base : this.base.replace(/\/$/, '') + path;
    return joined + hash;
  }

  /**
   * Rewrite in-document links from app paths to real URLs for this mode and
   * base. Doing it in the markup — rather than only intercepting clicks —
   * keeps the status bar honest and keeps middle-click, Ctrl-click and
   * "open in new tab" working.
   */
  rewriteLinks(root: ParentNode): void {
    if (this.mode === 'history' && this.base === '/') return;
    root.querySelectorAll<HTMLAnchorElement>('a[href^="/"]').forEach((a) => {
      const raw = a.getAttribute('href');
      if (!raw || a.dataset.rewritten === '1') return;
      const cut = raw.indexOf('#');
      const path = cut === -1 ? raw : raw.slice(0, cut) || '/';
      const hash = cut === -1 ? '' : raw.slice(cut);
      a.setAttribute('href', this.href(path, hash));
      a.dataset.rewritten = '1';
      a.dataset.path = path;
    });
  }

  /* --------------------------------------------------------------- events */

  private onClick = (e: MouseEvent): void => {
    if (e.defaultPrevented || e.button !== 0) return;
    if (e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;

    const anchor = (e.target as Element | null)?.closest?.('a');
    if (!anchor) return;

    const href = anchor.getAttribute('href');
    if (!href || anchor.hasAttribute('download')) return;
    if (anchor.target && anchor.target !== '_self') return;
    if (anchor.getAttribute('rel')?.includes('external')) return;
    if (/^(https?:)?\/\//i.test(href) && !href.startsWith(location.origin)) return;
    if (/^(mailto:|tel:|#)/i.test(href) && !anchor.dataset.path) {
      // A bare "#anchor" is an in-page jump; let scrollToHash smooth it out.
      if (href.startsWith('#')) {
        e.preventDefault();
        if (!scrollToHash(href, prefersReduced() ? 'instant' : 'smooth')) scrollToTop('smooth');
        this.pushHash(href);
      }
      return;
    }

    const url = new URL(anchor.href, location.href);
    if (url.origin !== location.origin) return;

    const target = this.targetFromURL(url);
    if (!target) return;

    e.preventDefault();
    void this.navigate(target.path, target.hash);
  };

  /**
   * App path and fragment for a same-origin URL, or null when the URL is
   * outside this app (a different base, or a plain in-page fragment in hash
   * mode). The single place that knows how each mode encodes a location.
   */
  private targetFromURL(url: URL): Target | null {
    if (this.mode === 'hash') {
      const raw = url.hash.slice(1);
      if (!raw.startsWith('/')) return null;
      const cut = raw.indexOf('#');
      return cut === -1
        ? { path: raw, hash: '' }
        : { path: raw.slice(0, cut) || '/', hash: raw.slice(cut) };
    }
    let path = url.pathname;
    if (this.base !== '/') {
      if (!path.startsWith(this.base)) return null;
      path = '/' + path.slice(this.base.length);
    }
    return { path: path || '/', hash: url.hash };
  }

  private onPop = (): void => {
    const target = this.readLocation();
    const route = this.resolve(target.path);
    const key = currentKey();

    if (route === this.current) {
      // Same page, different fragment (or a Back to a stored offset).
      if (target.hash) scrollToHash(target.hash, 'instant');
      else window.scrollTo({ top: recall(key), behavior: 'instant' });
      this.key = key;
      return;
    }

    remember(this.key);
    this.key = key;
    void this.commit(route, target.hash, recall(key), 'back');
  };

  /* ------------------------------------------------------------ navigating */

  /** Programmatic navigation. Safe to call from anywhere. */
  async navigate(path: string, hash = '', replace = false): Promise<void> {
    const route = this.resolve(path);
    const url = this.href(route === this.fallback ? path : route.path, hash);

    if (route === this.current) {
      // In-page move: no transition, no remount — just go there.
      history[replace ? 'replaceState' : 'pushState'](mintKey(), '', url);
      this.key = currentKey();
      if (hash) {
        if (!scrollToHash(hash, prefersReduced() ? 'instant' : 'smooth')) scrollToTop('smooth');
      } else {
        scrollToTop(prefersReduced() ? 'instant' : 'smooth');
      }
      return;
    }

    remember(this.key);
    history[replace ? 'replaceState' : 'pushState'](mintKey(), '', url);
    this.key = currentKey();
    await this.commit(route, hash, 0, 'forward');
  }

  private pushHash(hash: string): void {
    const target = this.readLocation();
    history.pushState(mintKey(), '', this.href(target.path, hash));
    this.key = currentKey();
  }

  /* -------------------------------------------------------------- the swap */

  private async commit(
    route: Route,
    hash: string,
    scrollY: number,
    direction: 'forward' | 'back',
  ): Promise<void> {
    if (this.navigating) return;
    this.navigating = true;

    const root = document.documentElement;
    const reduce = prefersReduced();
    root.dataset.nav = direction;
    root.classList.add('is-navigating');
    this.sweep();

    const swap = (): void => {
      this.teardown?.();
      this.teardown = null;

      this.main.innerHTML = route.render();
      this.current = route;
      this.applyRoute(route);
      this.rewriteLinks(this.main);

      // A forward navigation lands on something new, so its opening section
      // rises in. Going Back returns to something already seen: fade only.
      this.main.classList.remove('page-enter');
      if (direction === 'forward' && !reduce && !hash) {
        this.main.classList.add('page-enter');
        window.setTimeout(() => this.main.classList.remove('page-enter'), 1200);
      }

      // Position before the new snapshot is taken, so the transition animates
      // between two correctly-scrolled frames instead of sliding afterwards.
      if (hash && scrollToHash(hash, 'instant')) {
        /* landed on the anchor */
      } else {
        window.scrollTo({ top: scrollY, behavior: 'instant' });
      }

      this.teardown = route.mount?.(this.main) ?? null;
    };

    if (canViewTransition && !reduce) {
      const start = (document as Document & {
        startViewTransition: (cb: () => void) => { finished: Promise<void> };
      }).startViewTransition;
      try {
        await start.call(document, swap).finished;
      } catch {
        /* a transition can be skipped or interrupted; the DOM is already correct */
      }
    } else if (reduce) {
      swap();
    } else {
      // No View Transitions (older Safari, Firefox before 144): a short fade
      // on <main> stands in for the cross-fade; the rise plays as normal.
      this.main.classList.add('is-leaving');
      await new Promise<void>((r) => setTimeout(r, 150));
      swap();
      requestAnimationFrame(() => this.main.classList.remove('is-leaving'));
    }

    root.classList.remove('is-navigating');
    delete root.dataset.nav;

    // Move focus into the new page and say its name. Without this, a keyboard
    // or screen-reader user is left in the old document's tab order with no
    // indication that anything happened.
    this.main.focus({ preventScroll: true });
    const live = document.getElementById('routeLive');
    if (live) live.textContent = `${route.meta.title} — page loaded`;

    this.navigating = false;
  }

  /** Restart the hairline sweep under the nav. */
  private sweep(): void {
    const bar = document.querySelector<HTMLElement>('.nav-progress');
    if (!bar || prefersReduced()) return;
    bar.classList.remove('sweep');
    void bar.offsetWidth; // restart the animation from frame zero
    bar.classList.add('sweep');
  }

  /** Head, theme and nav state for a route. */
  private applyRoute(route: Route): void {
    applyMeta(route.meta);
    const root = document.documentElement;
    root.dataset.theme = route.theme;
    root.dataset.route = route.id;

    const here = this.href(route.path, '');
    document.querySelectorAll<HTMLAnchorElement>('.nav-links a, .foot-nav a').forEach((a) => {
      const active = a.getAttribute('href') === here;
      if (active) a.setAttribute('aria-current', 'page');
      else a.removeAttribute('aria-current');
    });
  }
}
